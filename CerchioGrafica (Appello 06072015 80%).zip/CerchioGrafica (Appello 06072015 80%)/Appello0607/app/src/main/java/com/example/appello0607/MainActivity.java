package com.example.appello0607;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    private FrameLayout frame;
    private ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        frame = findViewById(R.id.frame);
        image = findViewById(R.id.image);
        frame.getWidth();
    }

    public void moveLeft(View v) {
        FrameLayout.LayoutParams paramsLeft = (FrameLayout.LayoutParams) image.getLayoutParams();
        if ((paramsLeft.leftMargin - 50) >= 0) {
            image.setLayoutParams(paramsLeft);
            paramsLeft.leftMargin -= 50;
        }
    }

    public void moveRight(View v) {
        FrameLayout.LayoutParams paramsRight = (FrameLayout.LayoutParams) image.getLayoutParams();
        int width = frame.getWidth() - image.getWidth();
        if ((paramsRight.leftMargin + 50) <= width) {
            image.setLayoutParams(paramsRight);
            paramsRight.leftMargin += 50;
        }
    }

    public void moveCenter(View v) {
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) frame.getLayoutParams();
        FrameLayout.LayoutParams paramsImg = (FrameLayout.LayoutParams) image.getLayoutParams();
        float width = frame.getWidth();
        float height = frame.getHeight();
        paramsImg.topMargin = (int) height/2 - image.getHeight();
        paramsImg.leftMargin = (int) width/2 - image.getWidth();
        image.setLayoutParams(paramsImg);
        Log.d("moveUp", "height frame: " + height);
        Log.d("moveUp", "width frame: " + width);
        Log.d("moveUp", "image top margin: " + paramsImg.topMargin);
        Log.d("moveUp", "image left margin: " + paramsImg.leftMargin);
    }

    public void moveUp(View v) {
        FrameLayout.LayoutParams paramsTop = (FrameLayout.LayoutParams) image.getLayoutParams();
        if ((paramsTop.topMargin - 50) >= 0) {
            image.setLayoutParams(paramsTop);
            paramsTop.topMargin -= 50;
        }
        Log.d("moveUp", "topMargin: " + paramsTop.topMargin);
    }

    public void moveDown(View v) {
        FrameLayout.LayoutParams paramsTop = (FrameLayout.LayoutParams) image.getLayoutParams();
        int height = frame.getWidth();
        if ((paramsTop.topMargin + 50) < height) {
            image.setLayoutParams(paramsTop);
            paramsTop.topMargin += 50;
        }
    }
}