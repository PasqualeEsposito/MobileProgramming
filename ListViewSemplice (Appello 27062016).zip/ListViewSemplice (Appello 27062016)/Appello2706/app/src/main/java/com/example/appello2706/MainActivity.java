package com.example.appello2706;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public ArrayList<String> list;
    public ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = new ArrayList<>();

        if(savedInstanceState != null) {
            ArrayList<String> oldList = savedInstanceState.getStringArrayList("NOMI");
            list = oldList;
        }

        ListView listView = findViewById(R.id.listaXML);

        adapter = new ArrayAdapter<String>(this, R.layout.item_layout, R.id.listItem, list);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String  str  = listView.getItemAtPosition(position).toString();
                showDialog(view, str, position);
            }
        });
    }

    public void showDialog(View v, String name, int position) {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:
                        list.remove(position);
                        adapter.notifyDataSetChanged();
                        Toast.makeText(getApplicationContext(), name + " eliminato!", Toast.LENGTH_LONG).show();
                        break;
                    case DialogInterface.BUTTON_NEGATIVE:
                        Toast.makeText(getApplicationContext(), "Operazione annullata", Toast.LENGTH_LONG).show();
                        break;
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Sei sicuro di voler eliminare " + name + " dalla lista?")
                .setPositiveButton("Sì", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();

        return;
    }

    public void insert(View v) {
        EditText text = findViewById(R.id.input);
        String input = text.getText().toString();
        text.setText("");
        list.add(input);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {

        outState.putStringArrayList("NOMI", list);
        super.onSaveInstanceState(outState);
    }

}