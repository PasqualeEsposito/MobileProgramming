package com.example.appello3101;

import android.app.Activity;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;


public class Tris extends Fragment implements View.OnClickListener {

    private final int INIT = 5;
    AddSignListener listener = null;
    private int[] cells = new int[9];
    private int sign; //if sign == 1, then sign is "X", otherwise it is "Y"
    private TextView[] tris = new TextView[9];

    public interface AddSignListener {
        void onSignAddedX(int index);

        void onSignAddedO(int index);

        void stop1();

        void stop0();

        void setNotClickableX();

        void setNotClickableO();
    }

    public Tris() {
        // Required empty public constructor
    }

    public void setSign(int i) {
        sign = i;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            listener = (AddSignListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement AuthorSelectionListener");
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_tris, container, false);

        tris[0] = v.findViewById(R.id.t00);
        tris[1] = v.findViewById(R.id.t01);
        tris[2] = v.findViewById(R.id.t02);
        tris[3] = v.findViewById(R.id.t10);
        tris[4] = v.findViewById(R.id.t11);
        tris[5] = v.findViewById(R.id.t12);
        tris[6] = v.findViewById(R.id.t20);
        tris[7] = v.findViewById(R.id.t21);
        tris[8] = v.findViewById(R.id.t22);

        for (TextView t : tris)
            t.setOnClickListener(this::onClick);

        for(int i = 0; i < 9; i++)
            cells[i] = INIT;

        return v;
    }

    public void onClick(View v) {
        TextView tv = (TextView) v;
        if (tv.getText().toString().compareTo("") == 0 && sign == 1) {
            tv.setText("X");
            cells[Integer.parseInt(tv.getTag().toString())] = 1;
        } else {
            tv.setText("O");
            cells[Integer.parseInt(tv.getTag().toString())] = 0;
        }
        if (sign == 1)
            listener.onSignAddedO(Integer.parseInt(tv.getTag().toString()));
        else
            listener.onSignAddedX(Integer.parseInt(tv.getTag().toString()));
        checkVictory();
    }

    public void addSign(int index) {
        TextView tv = tris[index];
        if (sign == 0) {
            tv.setText("X");
            listener.setNotClickableX();
        }
        if (sign == 1) {
            tv.setText("O");
            listener.setNotClickableO();
        }
    }

    public void checkVictory() {
        String case1 = "" + cells[0] + cells[1] + cells[2];
        String case2 = "" + cells[3] + cells[4] + cells[5];
        String case3 = "" + cells[6] + cells[7] + cells[8];
        String case4 = "" + cells[0] + cells[3] + cells[6];
        String case5 = "" + cells[1] + cells[4] + cells[7];
        String case6 = "" + cells[2] + cells[5] + cells[8];
        String case7 = "" + cells[0] + cells[4] + cells[8];
        String case8 = "" + cells[2] + cells[4] + cells[6];

        if(sign == 0) {
            if (case1.compareTo("000") == 0 || case2.compareTo("000") == 0 ||
                    case3.compareTo("000") == 0 || case4.compareTo("000") == 0 ||
                    case5.compareTo("000") == 0 || case6.compareTo("000") == 0 ||
                    case7.compareTo("000") == 0 || case8.compareTo("000") == 0)
                listener.stop0();
        }
        if(sign == 1) {
            if (case1.compareTo("111") == 0 || case2.compareTo("111") == 0 ||
                    case3.compareTo("111") == 0 || case4.compareTo("111") == 0 ||
                    case5.compareTo("111") == 0 || case6.compareTo("111") == 0 ||
                    case7.compareTo("111") == 0 || case8.compareTo("111") == 0)
                listener.stop1();
        }
    }

    public void notClickable() {
        for(int i = 0; i < 9; i++)
            tris[i].setClickable(false);
    }

    public void clickable() {
        for(int i = 0; i < 9; i++)
            tris[i].setClickable(true);
    }

    public void reset() {
        for(int i = 0; i < 9; i++) {
            cells[i] = INIT;
            tris[i].setText("");
        }
    }
}