package com.example.appello3101;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements Tris.AddSignListener {

    private Tris t1;
    private Tris t2;
    private TextView textWin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t1 = new Tris();
        t2 = new Tris();

        t1.setSign(1);
        t2.setSign(0);

        textWin = findViewById(R.id.textWin);

        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.add(R.id.tris1, t1);
        ft.add(R.id.tris2, t2);
        ft.commit();
        fm.executePendingTransactions();

    }

    @Override
    public void onSignAddedO(int index) {
        t2.addSign(index);
    }

    @Override
    public void onSignAddedX(int index) {
        t1.addSign(index);
    }

    @Override
    public void stop0() {
        textWin.setText("O ha vinto!");
    }

    @Override
    public void setNotClickableX() {
        t1.notClickable();
        t2.clickable();
    }

    @Override
    public void setNotClickableO() {
        t2.notClickable();
        t1.clickable();
    }

    @Override
    public void stop1() {
        textWin.setText("X ha vinto!");
    }

    public void reset(View v) {
        t1.reset();
        t2.reset();
        t1.clickable();
        t2.clickable();
        textWin.setText("");
    }
}