package com.example.appello0902;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private ImageView immagine;
    private TextView numPassaggi;
    private Button buttonLeft;
    private Button buttonRight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        immagine = findViewById(R.id.immagine);
        numPassaggi = findViewById(R.id.numeroPassaggi);

        buttonLeft = findViewById(R.id.sinistra);
        buttonRight = findViewById(R.id.destra);
    }

    public void muoviADestra(View v) {
        buttonLeft.setEnabled(false);
        buttonRight.setEnabled(true);
        int counter = Integer.parseInt(numPassaggi.getText().toString());
        numPassaggi.setText("" + ++counter);
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.animazione_verso_destra);
        immagine.startAnimation(animation);
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                animation.setFillAfter(true);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    public void muoviASinistra(View v) {
        buttonLeft.setEnabled(true);
        buttonRight.setEnabled(false);
        int counter = Integer.parseInt(numPassaggi.getText().toString());
        numPassaggi.setText("" + ++counter);
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.animazione_verso_sinistra);
        immagine.startAnimation(animation);
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                animation.setFillAfter(true);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }
}