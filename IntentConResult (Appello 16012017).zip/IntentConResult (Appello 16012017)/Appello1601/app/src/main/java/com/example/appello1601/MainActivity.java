package com.example.appello1601;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public TextView string;
    public TextView number;
    public String oldString;
    public int oldNumber;
    SharedPreferences pref;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        string = findViewById(R.id.text_a);
        number = findViewById(R.id.text_b);

        pref = this.getSharedPreferences("MyPref", Context.MODE_PRIVATE);
        oldString = pref.getString("STRINGA", null);
        oldNumber = pref.getInt("NUMERO", -1000000000);

        string.setText(oldString);
        number.setText("" + oldNumber);
    }

    public void launchActivityA(View v) {
        Intent i = new Intent();
        i.setClass(this, ActivityA.class);
        i.putExtra("STRINGA", oldString);
        startActivityForResult(i, 0);
    }

    public void launchActivityB(View v) {
        Intent i = new Intent();
        i.setClass(this, ActivityB.class);
        i.putExtra("NUMERO", oldNumber);
        startActivityForResult(i, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK)
            return;
        if (requestCode == 0) {
            string.setText(data.getStringExtra("STRINGA"));
            oldString = data.getStringExtra("STRINGA");
        }
        if (requestCode == 1) {
            number.setText("" + data.getIntExtra("NUMERO", -1000000000));
            oldNumber = data.getIntExtra("NUMERO", -1000000000);
        }
    }

    @Override
    protected void onDestroy() {
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("STRINGA", oldString);
        editor.putInt("NUMERO", oldNumber);
        super.onDestroy();
    }
}