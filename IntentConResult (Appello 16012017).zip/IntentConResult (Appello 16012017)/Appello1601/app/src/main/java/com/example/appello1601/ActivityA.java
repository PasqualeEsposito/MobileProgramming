package com.example.appello1601;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.Nullable;

public class ActivityA extends Activity {

    EditText string;
    SharedPreferences pref;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a);
        pref = this.getSharedPreferences("MyPref", 0);
        string = findViewById(R.id.stringaA);

        Intent i = getIntent();
        String stringa = i.getStringExtra("STRINGA");

        string.setText(stringa);
    }

    public void backFromA(View v) {
        SharedPreferences.Editor editor = pref.edit();
        String stringa = string.getText().toString();
        editor.putString("STRINGA", "" + stringa);
        editor.commit();
        setReturnIntent(stringa);
        onBackPressed();
    }

    public void setReturnIntent(String string) {
        Intent data = new Intent();
        data.putExtra("STRINGA", string);
        setResult(RESULT_OK, data);
        finish();
    }
}
