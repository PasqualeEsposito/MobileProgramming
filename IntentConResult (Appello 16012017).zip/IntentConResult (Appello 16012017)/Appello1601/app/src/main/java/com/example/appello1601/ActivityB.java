package com.example.appello1601;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.Nullable;

public class ActivityB extends Activity {

    EditText number;
    SharedPreferences pref;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);
        pref = this.getSharedPreferences("MyPref", 0);
        number = findViewById(R.id.numberoB);

        Intent i = getIntent();
        int numero = i.getIntExtra("NUMERO", -1000000000);

        number.setText("" + numero);
    }

    public void backFromB(View v) {
        SharedPreferences.Editor editor = pref.edit();
        int numero = Integer.parseInt(number.getText().toString());
        editor.putInt("NUMERO", numero);
        editor.commit();
        setReturnIntent(numero);
        onBackPressed();
    }

    public void setReturnIntent(int numero) {
        Intent data = new Intent();
        data.putExtra("NUMERO", numero);
        setResult(RESULT_OK, data);
        finish();
    }
}
