package com.example.appello2701;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Activity3 extends AppCompatActivity {

    String activity1;
    String activity2;
    String activity3;
    EditText string3;
    TextView string1;
    TextView string2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        string1 = findViewById(R.id.BString1);
        string2 = findViewById(R.id.BString2);
        string3 = findViewById(R.id.BString);

        Intent i = getIntent();
        activity1 = i.getStringExtra("STRING1");
        activity2 = i.getStringExtra("STRING2");
        activity3 = i.getStringExtra("STRING3");
        string1.setText(activity1);
        string2.setText(activity2);
        string3.setText(activity3);
    }

    public void launchMainActivity(View v) {
        activity3 = string3.getText().toString();
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("STRING1", activity1);
        i.putExtra("STRING2", activity2);
        i.putExtra("STRING3", activity3);
        startActivity(i);
        finish();
    }

    public void launchActivity2(View v) {
        activity3 = string3.getText().toString();
        Intent i = new Intent(this, Activity2.class);
        i.putExtra("STRING1", activity1);
        i.putExtra("STRING2", activity2);
        i.putExtra("STRING3", activity3);
        startActivity(i);
        finish();
    }
}