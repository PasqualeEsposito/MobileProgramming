package com.example.appello2701;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.IntentCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    String activity1;
    String activity2;
    String activity3;
    EditText string1;
    TextView string2;
    TextView string3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        string1 = findViewById(R.id.activity1);
        string2 = findViewById(R.id.mainString2);
        string3 = findViewById(R.id.mainString3);

        Intent i = getIntent();
        activity1 = i.getStringExtra("STRING1");
        activity2 = i.getStringExtra("STRING2");
        activity3 = i.getStringExtra("STRING3");
        string1.setText(activity1);
        string2.setText(activity2);
        string3.setText(activity3);
    }

    public void launchActivity2(View v) {
        activity1 = string1.getText().toString();
        Intent i = new Intent(this, Activity2.class);
        i.putExtra("STRING1", activity1);
        i.putExtra("STRING2", activity2);
        i.putExtra("STRING3", activity3);
        startActivity(i);
        finish();
    }

    public void launchActivity3(View v) {
        activity1 = string1.getText().toString();
        Intent i = new Intent(this, Activity3.class);
        i.putExtra("STRING1", activity1);
        i.putExtra("STRING2", activity2);
        i.putExtra("STRING3", activity3);
        startActivity(i);
        finish();
    }
}