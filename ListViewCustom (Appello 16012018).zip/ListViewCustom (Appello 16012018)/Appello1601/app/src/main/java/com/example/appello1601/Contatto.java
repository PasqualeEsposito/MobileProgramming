package com.example.appello1601;

import java.io.Serializable;

public class Contatto implements Serializable {
    private String name;
    private String surname;
    private String number;

    public Contatto(String name, String surname, String telephone) {
        this.name = name;
        this.surname = surname;
        this.number = telephone;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getNumber() {
        return number;
    }
}
