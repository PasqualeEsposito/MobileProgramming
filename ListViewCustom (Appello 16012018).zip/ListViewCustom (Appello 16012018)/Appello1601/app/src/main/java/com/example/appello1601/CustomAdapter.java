package com.example.appello1601;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class CustomAdapter extends ArrayAdapter<Contatto> {

    private LayoutInflater inflater;

    public CustomAdapter(Context context, int resourceId, List<Contatto> contatti) {
        super(context, resourceId, contatti);
        inflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null)
            convertView = inflater.inflate(R.layout.item_layout, null);

        Contatto c = getItem(position);
        TextView name = convertView.findViewById(R.id.nameItem);
        TextView surname = convertView.findViewById(R.id.surnameItem);
        TextView number = convertView.findViewById(R.id.phoneItem);

        name.setText(c.getName());
        surname.setText(c.getSurname());
        number.setText(c.getNumber());
        return convertView;
    }
}
