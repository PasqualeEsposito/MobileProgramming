package com.example.appello2307;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public Button minus1;
    public Button minus2;
    public Button minus3;
    public Button minus4;
    public Button minus5;
    public Button minus6;
    public Button minus7;

    public TextView number1;
    public TextView number2;
    public TextView number3;
    public TextView number4;
    public TextView number5;
    public TextView number6;
    public TextView number7;

    public Button plus1;
    public Button plus2;
    public Button plus3;
    public Button plus4;
    public Button plus5;
    public Button plus6;
    public Button plus7;

    public TextView result;

    int[] numbers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        minus1 = findViewById(R.id.minus1);
        minus2 = findViewById(R.id.minus2);
        minus3 = findViewById(R.id.minus3);
        minus4 = findViewById(R.id.minus4);
        minus5 = findViewById(R.id.minus5);
        minus6 = findViewById(R.id.minus6);
        minus7 = findViewById(R.id.minus7);

        number1 = findViewById(R.id.number1);
        number2 = findViewById(R.id.number2);
        number3 = findViewById(R.id.number3);
        number4 = findViewById(R.id.number4);
        number5 = findViewById(R.id.number5);
        number6 = findViewById(R.id.number6);
        number7 = findViewById(R.id.number7);

        plus1 = findViewById(R.id.plus1);
        plus2 = findViewById(R.id.plus2);
        plus3 = findViewById(R.id.plus3);
        plus4 = findViewById(R.id.plus4);
        plus5 = findViewById(R.id.plus5);
        plus6 = findViewById(R.id.plus6);
        plus7 = findViewById(R.id.plus7);

        result = findViewById(R.id.result);

        numbers = new int[7];
        numbers[0] = Integer.parseInt(number1.getText().toString());
        numbers[1] = Integer.parseInt(number2.getText().toString());
        numbers[2] = Integer.parseInt(number3.getText().toString());
        numbers[3] = Integer.parseInt(number4.getText().toString());
        numbers[4] = Integer.parseInt(number5.getText().toString());
        numbers[5] = Integer.parseInt(number6.getText().toString());
        numbers[6] = Integer.parseInt(number7.getText().toString());

        minus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(numbers[0] == 0)
                    return;
                number1.setText("" + --numbers[0]);
            }
        });

        minus2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(numbers[1] == 0)
                    return;
                number2.setText("" + --numbers[1]);
            }
        });

        minus3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(numbers[2] == 0)
                    return;
                number3.setText("" + --numbers[2]);
            }
        });

        minus4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(numbers[3] == 0)
                    return;
                number4.setText("" + --numbers[3]);
            }
        });

        minus5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(numbers[4] == 0)
                    return;
                number5.setText("" + --numbers[4]);
            }
        });

        minus6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(numbers[5] == 0)
                    return;
                number6.setText("" + --numbers[5]);
            }
        });

        minus7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(numbers[6] == 0)
                    return;
                number7.setText("" + --numbers[6]);
            }
        });

        plus1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(numbers[0] == 20)
                    return;
                number1.setText("" + ++numbers[0]);
            }
        });

        plus2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(numbers[1] == 20)
                    return;
                number2.setText("" + ++numbers[1]);
            }
        });

        plus3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(numbers[2] == 20)
                    return;
                number3.setText("" + ++numbers[2]);
            }
        });
        plus4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(numbers[3] == 20)
                    return;
                number4.setText("" + ++numbers[3]);
            }
        });
        plus5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(numbers[4] == 20)
                    return;
                number5.setText("" + ++numbers[4]);
            }
        });
        plus6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(numbers[5] == 20)
                    return;
                number6.setText("" + ++numbers[5]);
            }
        });
        plus7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(numbers[6] == 20)
                    return;
                number7.setText("" + ++numbers[6]);
            }
        });
    }

    public void somma(View v) {
        int sum = 0;
        for(int i = 0; i < numbers.length; i++)
            sum += numbers[i];
        result.setText("" + sum);
    }

    public void prodotto(View v) {
        int multiply = 1;
        for(int i = 0; i < numbers.length; i++)
            multiply *= numbers[i];
        result.setText("" + multiply);
    }
}