package com.example.appello2701;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    private final int NULL = 5;
    private int[] tris = new int[9];
    private int segno = 1; //segno=1, allora X, segno=0 allora O
    private TextView[] cells = new TextView[9];
    private TextView startSign;
    private TextView actualSign;
    private TextView winningSign;
    private TextView scritta;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cells[0] = findViewById(R.id.t00);
        cells[1] = findViewById(R.id.t01);
        cells[2] = findViewById(R.id.t02);
        cells[3] = findViewById(R.id.t10);
        cells[4] = findViewById(R.id.t11);
        cells[5] = findViewById(R.id.t12);
        cells[6] = findViewById(R.id.t20);
        cells[7] = findViewById(R.id.t21);
        cells[8] = findViewById(R.id.t22);

        winningSign = findViewById(R.id.winningSign);
        scritta = findViewById(R.id.scritta);

        for (int i = 0; i < 9; i++) {
            cells[i].setClickable(false);
            tris[i] = NULL;

            startSign = findViewById(R.id.startSign);
            actualSign = findViewById(R.id.actualSign);
        }
    }

    public void reset(View v) {
        for (int i = 0; i < 9; i++) {
            cells[i].setText("");
            cells[i].setClickable(false);
        }
        for (int i = 0; i < 9; i++)
            tris[i] = NULL;
        winningSign.setText("");
    }

    public void chooseSign(View v) {
        switch (segno) {
            case 1:
                segno = 0;
                startSign.setText("O");
                actualSign.setText("O");
                break;
            case 0:
                segno = 1;
                startSign.setText("X");
                actualSign.setText("X");
        }
        for (int i = 0; i < 9; i++)
            cells[i].setClickable(true);
        scritta.setVisibility(View.INVISIBLE);
    }

    public void add(View v) {
        int tmp = v.getId(), i = 0;
        for (; i < 9; i++)
            if (cells[i].getId() == tmp)
                break;
        if (cells[i].getText().toString().compareTo("") == 0) {
            if (segno == 1) {
                cells[i].setText("X");
                tris[i] = 1;
                segno = 0;
                actualSign.setText("O");
            } else {
                cells[i].setText("O");
                tris[i] = 0;
                segno = 1;
                actualSign.setText("X");
            }
        } else
            return;

        checkVictory();
    }

    public void checkVictory() {
        String case1 = "" + tris[0] + tris[1] + tris[2];
        String case2 = "" + tris[3] + tris[4] + tris[5];
        String case3 = "" + tris[6] + tris[7] + tris[8];
        String case4 = "" + tris[0] + tris[3] + tris[6];
        String case5 = "" + tris[1] + tris[4] + tris[7];
        String case6 = "" + tris[2] + tris[5] + tris[8];
        String case7 = "" + tris[0] + tris[4] + tris[8];
        String case8 = "" + tris[2] + tris[4] + tris[6];

        if (case1.compareTo("000") == 0 || case1.compareTo("111") == 0)
            stop();
        if (case2.compareTo("000") == 0 || case2.compareTo("111") == 0)
            stop();
        if (case3.compareTo("000") == 0 || case3.compareTo("111") == 0)
            stop();
        if (case4.compareTo("000") == 0 || case4.compareTo("111") == 0)
            stop();
        if (case5.compareTo("000") == 0 || case5.compareTo("111") == 0)
            stop();
        if (case6.compareTo("000") == 0 || case6.compareTo("111") == 0)
            stop();
        if (case7.compareTo("000") == 0 || case7.compareTo("111") == 0)
            stop();
        if (case8.compareTo("000") == 0 || case8.compareTo("111") == 0)
            stop();
    }

    public void stop() {
        for (int i = 0; i < 9; i++)
            cells[i].setClickable(false);
        if(segno == 0)
            winningSign.setText("X ha vinto!");
        else
            winningSign.setText("O ha vinto!");
        scritta.setVisibility(View.VISIBLE);
    }
}