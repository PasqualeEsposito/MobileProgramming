package com.example.appello1411;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public int total;
    public int firstCourseActualPrice;
    public int secondCourseActualPrice;
    public int sideDishActualPrice;
    public int fruitActualPrice;
    public RadioButton firstCourse3;
    public RadioButton firstCourse5;
    public RadioButton firstCourse7;
    public RadioButton secondCourse3;
    public RadioButton secondCourse5;
    public RadioButton secondCourse7;
    public RadioButton sideDish3;
    public RadioButton sideDish5;
    public RadioButton sideDish7;
    public RadioButton fruit3;
    public RadioButton fruit5;
    public RadioButton fruit7;
    public TextView totalActualPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        total = 0;
        totalActualPrice = findViewById(R.id.totale);
        firstCourse3 = findViewById(R.id.primo3);
        firstCourse5 = findViewById(R.id.primo5);
        firstCourse7 = findViewById(R.id.primo7);
        secondCourse3 = findViewById(R.id.secondo3);
        secondCourse5 = findViewById(R.id.secondo5);
        secondCourse7 = findViewById(R.id.secondo7);
        sideDish3 = findViewById(R.id.contorno3);
        sideDish5 = findViewById(R.id.contorno5);
        sideDish7 = findViewById(R.id.contorno7);
        fruit3 = findViewById(R.id.frutta3);
        fruit5 = findViewById(R.id.frutta5);
        fruit7 = findViewById(R.id.frutta7);

        firstCourse3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (firstCourseActualPrice != 0)
                    total -= firstCourseActualPrice;
                total += 3;
                firstCourseActualPrice = 3;
                totalActualPrice.setText(total + "€");
            }
        });

        firstCourse5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (firstCourseActualPrice != 0)
                    total -= firstCourseActualPrice;
                total += 5;
                firstCourseActualPrice = 5;
                totalActualPrice.setText(total + "€");
            }
        });

        firstCourse7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (firstCourseActualPrice != 0)
                    total -= firstCourseActualPrice;
                total += 7;
                firstCourseActualPrice = 7;
                totalActualPrice.setText(total + "€");
            }
        });

        secondCourse3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (secondCourseActualPrice != 0)
                    total -= secondCourseActualPrice;
                total += 3;
                secondCourseActualPrice = 3;
                totalActualPrice.setText(total + "€");
            }
        });

        secondCourse5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (secondCourseActualPrice != 0)
                    total -= secondCourseActualPrice;
                total += 5;
                secondCourseActualPrice = 5;
                totalActualPrice.setText(total + "€");
            }
        });

        secondCourse7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (secondCourseActualPrice != 0)
                    total -= secondCourseActualPrice;
                total += 7;
                secondCourseActualPrice = 7;
                totalActualPrice.setText(total + "€");
            }
        });

        sideDish3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sideDishActualPrice != 0)
                    total -= sideDishActualPrice;
                total += 3;
                sideDishActualPrice = 3;
                totalActualPrice.setText(total + "€");
            }
        });

        sideDish5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sideDishActualPrice != 0)
                    total -= sideDishActualPrice;
                total += 5;
                sideDishActualPrice = 5;
                totalActualPrice.setText(total + "€");
            }
        });

        sideDish7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sideDishActualPrice != 0)
                    total -= sideDishActualPrice;
                total += 7;
                sideDishActualPrice = 7;
                totalActualPrice.setText(total + "€");
            }
        });

        fruit3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (fruitActualPrice != 0)
                    total -= fruitActualPrice;
                total += 3;
                fruitActualPrice = 3;
                totalActualPrice.setText(total + "€");
            }
        });

        fruit5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (fruitActualPrice != 0)
                    total -= fruitActualPrice;
                total += 5;
                fruitActualPrice = 5;
                totalActualPrice.setText(total + "€");
            }
        });

        fruit7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (fruitActualPrice != 0)
                    total -= fruitActualPrice;
                total += 7;
                fruitActualPrice = 7;
                totalActualPrice.setText(total + "€");
            }
        });
    }


    public void subtotal(View v) {
        Intent i = new Intent();
        i.setClass(this, Subtotal.class);
        i.putExtra("TOTALE_PASTO", total);
        i.putExtra("PRIMO", firstCourseActualPrice);
        i.putExtra("SECONDO", secondCourseActualPrice);
        i.putExtra("CONTORNO", sideDishActualPrice);
        i.putExtra("FRUTTA", fruitActualPrice);
        startActivity(i);
    }
}