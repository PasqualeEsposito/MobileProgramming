package com.example.appello1411;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Subtotal extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.subtotal);

        Intent i = getIntent();
        int totale = i.getIntExtra("TOTALE_PASTO", 0);
        int primo = i.getIntExtra("PRIMO", 0);
        int secondo = i.getIntExtra("SECONDO", 0);
        int contorno = i.getIntExtra("CONTORNO", 0);
        int frutta = i.getIntExtra("FRUTTA", 0);

        TextView total = findViewById(R.id.finalPrice);
        TextView firstCourse = findViewById(R.id.firstCourse);
        TextView secondCourse = findViewById(R.id.secondCourse);
        TextView sideDish = findViewById(R.id.sideDish);
        TextView fruit = findViewById(R.id.fruit);

        total.setText(totale + "€");
        firstCourse.setText(primo + "€");
        secondCourse.setText(secondo + "€");
        sideDish.setText(contorno + "€");
        fruit.setText(frutta + "€");
    }
}
