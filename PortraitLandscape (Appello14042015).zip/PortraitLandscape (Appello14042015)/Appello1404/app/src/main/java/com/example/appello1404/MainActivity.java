package com.example.appello1404;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView text;
    private Button white;
    private Button red;
    private Button green;
    private Button blue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int orientation = getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            setContentView(R.layout.activity_main_portrait);
        } else {
            setContentView(R.layout.activity_main_landscape);
        }

        text = findViewById(R.id.text);

        white = findViewById(R.id.white);
        red = findViewById(R.id.red);
        green = findViewById(R.id.green);
        blue = findViewById(R.id.blue);


        white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                text.setBackgroundColor(Color.WHITE);
            }
        });

        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                text.setBackgroundColor(Color.RED);
            }
        });

        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                text.setBackgroundColor(Color.GREEN);
            }
        });

        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                text.setBackgroundColor(Color.BLUE);
            }
        });
    }

    public void reset(View v) {
        text.setText("1");
    }

    public void multiply(View v) {
        int number = Integer.parseInt(text.getText().toString());
        number *= 2;
        text.setText("" + number);
    }

    public void divide(View v) {
        int number = Integer.parseInt(text.getText().toString());
        number /= 2;
        text.setText("" + number);
    }

    public void logarithm(View v) {
        int number = Integer.parseInt(text.getText().toString());
        number = (int)(Math.log(number) / Math.log(2));
        text.setText("" + number);
    }
}