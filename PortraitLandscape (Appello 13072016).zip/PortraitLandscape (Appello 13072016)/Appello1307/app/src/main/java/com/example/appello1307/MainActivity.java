package com.example.appello1307;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText text1;
    private EditText text2;
    private int number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int orientation = getResources().getConfiguration().orientation;

        if (savedInstanceState != null)
            number = Integer.parseInt(savedInstanceState.getString("NUMERO"));

        if (orientation == Configuration.ORIENTATION_PORTRAIT)
            portrait();
        else
            landscape();
    }

    public void portrait() {
        setContentView(R.layout.activity_main_portrait);
        text1 = findViewById(R.id.text1);
        text1.setText("" + number);
    }

    public void landscape() {
        setContentView(R.layout.activity_main_landscape);
        text2 = findViewById(R.id.text2);
        text2.setText("" + number);
    }

    public void add10(View v) {
        number = Integer.parseInt(text1.getText().toString());
        number += 10;
        text1.setText("" + number);
    }

    public void subtract10(View v) {
        number = Integer.parseInt(text1.getText().toString());
        number -= 10;
        text1.setText("" + number);
    }

    public void exponentation(View v) {
        number = Integer.parseInt(text2.getText().toString());
        number = (int) Math.pow(number, 2);
        text2.setText("" + number);
    }

    public void doubling(View v) {
        number = Integer.parseInt(text2.getText().toString());
        number *= 2;
        text2.setText("" + number);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putString("NUMERO", "" + number);
        super.onSaveInstanceState(outState);
    }
}